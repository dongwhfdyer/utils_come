#!/bin/bash
# Example training script for Model B

echo "Starting Model B training..."
echo "Using GPUs: $CUDA_VISIBLE_DEVICES"
echo "Timestamp: $(date)"

# Simulate training workload
for i in {1..15}; do
    echo "Epoch $i: Training model B..."
    sleep 4
done

echo "Model B training completed successfully!"
echo "Final timestamp: $(date)"