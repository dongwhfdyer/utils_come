#!/bin/bash
# Long-running test script for kill testing

echo "Long-running task started..."
echo "Using GPUs: $CUDA_VISIBLE_DEVICES"
echo "Timestamp: $(date)"

for i in {1..100}; do
    echo "Long task step $i..."
    sleep 2
done

echo "Long task completed!"