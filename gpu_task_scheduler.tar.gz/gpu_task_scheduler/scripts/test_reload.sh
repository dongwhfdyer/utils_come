#!/bin/bash
# Test script for reload functionality

echo "Test task started..."
echo "Using GPUs: $CUDA_VISIBLE_DEVICES"
echo "Timestamp: $(date)"

for i in {1..5}; do
    echo "Test step $i..."
    sleep 2
done

echo "Test task completed!"