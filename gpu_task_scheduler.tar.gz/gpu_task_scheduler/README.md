# GPU Resource Manager

A complete task scheduling system designed for deep learning platforms that maintains persistent GPU occupation while managing a queue of training and inference tasks.

## Control Mode

📁 **File-Based Mode**: Signal file control for platform deployment and local use

## Overview

This system is designed to bypass platform scheduling limitations by:
- Running indefinitely to maintain resource occupation
- Managing internal task queues with concurrent and sequential execution
- Automatically switching between GPU occupation and real tasks
- Providing complete process management and monitoring
- Using a single, robust file-based control method

## Features

- **Persistent Resource Occupation**: Maintains GPU utilization when no tasks are running
- **Mixed Task Execution**: Supports both concurrent and sequential task scheduling
- **Real-time Process Management**: Full subprocess tracking with PID management
- **File-Based Control**: Single control interface via signal files in `control/`
- **Platform Compatibility**: Works on restrictive training platforms without terminal access
- **Execution History**: Complete logging and audit trail of all task executions
- **YAML Configuration**: Human-readable task definitions with hot-reload capability
- **GPU Conflict Detection**: Warns about overlapping GPU assignments
- **Graceful Shutdown**: Proper cleanup of all running processes

## System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                GPU Resource Manager                         │
├─────────────────────────────────────────────────────────────┤
│  Main Loop (while True)                                     │
│  ├── Task Monitor Thread                                    │
│  ├── Signal File Monitor                                    │
│  └── GPU Occupation Process                                 │
├─────────────────────────────────────────────────────────────┤
│  Task Queue Management                                      │
│  ├── Concurrent Tasks (run_together: true)                 │
│  ├── Sequential Tasks (run_together: false)                │
│  └── GPU Assignment & Conflict Detection                   │
├─────────────────────────────────────────────────────────────┤
│  Process Management                                         │
│  ├── subprocess.Popen tracking                             │
│  ├── PID management                                         │
│  └── Signal handling (SIGTERM/SIGKILL)                     │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

### 📁 File-Based Mode

1. **Start the file-based system**:
   ```bash
   python3 gpu_resource_manager.py
   ```

2. **Control via signal files**:
   ```bash
   # Request status
   echo "timestamp: $(date -Iseconds)" > control/status.request
   cat control/status.output

   # Reload configuration
   echo "timestamp: $(date -Iseconds)" > control/reload.signal

   # Kill specific task
   echo "task_id: training_job" > control/kill_task_training_job.signal

   # Shutdown system
   echo "timestamp: $(date -Iseconds)" > control/shutdown.signal
   ```

3. **Monitor system**:
   ```bash
   # View live status
   cat control/current_status.txt

   # View system log
   tail -f system.log
   ```

## When to Use

### 📁 **Use File-Based Mode When:**
- Deploying on training platforms (Google Colab, AWS SageMaker, etc.)
- No terminal access available
- System runs unattended
- Need to control via file uploads or scripts
- Platform restrictions prevent stdin/stdout interaction

## Configuration

### Task Definition (control/tasks.yaml)

```yaml
tasks:
  - id: training_model_a
    command: /path/to/train_script.sh
    gpu_indices: [0, 1, 2, 3]
    log_file: /path/to/logs/model_a.log
    run_together: true
    status: pending

  - id: sequential_preprocessing
    command: /path/to/preprocess.sh
    gpu_indices: [0, 1, 2, 3, 4, 5, 6, 7]
    log_file: /path/to/logs/preprocessing.log
    run_together: false
    status: pending
```

### Field Descriptions

- **id**: Unique task identifier
- **command**: Shell script or command to execute
- **gpu_indices**: List of GPU card indices to assign
- **log_file**: Path where task output will be logged
- **run_together**:
  - `true`: Can run concurrently with other concurrent tasks
  - `false`: Must run alone (sequential execution)
- **status**: Task state (pending/running/completed)

## Task Execution Logic

### Concurrent Tasks (`run_together: true`)
- Can start while other concurrent tasks are running
- Cannot start if any sequential task is running
- GPU conflicts issue warnings but allow execution

### Sequential Tasks (`run_together: false`)
- Must wait for ALL running tasks to complete
- Exclusive execution - no other tasks can run simultaneously
- Typically used for preprocessing or resource-intensive operations

### GPU Assignment
- Each task specifies exact GPU indices to use
- Environment variable `CUDA_VISIBLE_DEVICES` is automatically set
- Conflicts are detected and warned but execution is allowed
- Example: Task using GPUs [0,1] will have `CUDA_VISIBLE_DEVICES=0,1`

## Process Management

### Subprocess Tracking
- All tasks run as separate process groups using `os.setsid`
- Process objects stored with full PID tracking
- Automatic monitoring for completion detection

### Termination Handling
- Graceful termination: `SIGTERM` followed by 10-second timeout
- Force termination: `SIGKILL` if graceful shutdown fails
- Process group termination prevents orphaned processes

### GPU Occupation
- Automatically starts when no tasks are running
- Simple script that maintains minimal GPU utilization
- Immediately terminated when real tasks need resources
- Prevents platform from reclaiming idle resources

## File Management

### Execution History (control/execution_history.yaml)
```yaml
execution_history:
  - id: training_model_a
    command: /path/to/train_script.sh
    gpu_indices: [0, 1, 2, 3]
    started_at: 2025-09-28T10:30:00
    completed_at: 2025-09-28T12:45:00
    status: completed
    log_file: /path/to/logs/model_a.log
```

### Task Status Updates
- Original YAML file is automatically updated with task status changes
- Status progression: `pending` → `running` → `completed`
- Timestamps recorded for audit trail
- History file maintains complete execution log

## Command Reference (File-Based)

Create files in `control/` to issue commands:

| File | Purpose | Example content |
|------|---------|-----------------|
| `status.request` | Write status to `control/status.output` | `timestamp: 2025-09-29T12:00:00` |
| `reload.signal` | Reload tasks from YAML | `timestamp: 2025-09-29T12:00:00` |
| `kill_all.signal` | Kill all running tasks | `timestamp: 2025-09-29T12:00:00` |
| `kill_task_<task_id>.signal` | Kill specific task (legacy) | (empty is fine) |
| `kill.signal` | Kill specific task (preferred) | `task_id: training_model_a` |
| `shutdown.signal` | Graceful shutdown | `timestamp: 2025-09-29T12:00:00` |

### Status Output Example
```
=== GPU Resource Manager Status ===
Tasks file: tasks.yaml
Total tasks: 4

Running tasks (2):
  training_model_a: GPUs [0, 1, 2, 3], PID 12345
  training_model_b: GPUs [4, 5], PID 12346

Pending tasks (1):
  inference_batch: GPUs [6, 7], concurrent=true

GPU occupation: Stopped
```

## Example Usage Scenarios

### Scenario 1: Mixed Concurrent Training
```yaml
tasks:
  - id: model_a
    command: ./train_model_a.sh
    gpu_indices: [0, 1]
    run_together: true

  - id: model_b
    command: ./train_model_b.sh
    gpu_indices: [2, 3]
    run_together: true
```
Both models start simultaneously on different GPUs.

### Scenario 2: Sequential Preprocessing
```yaml
tasks:
  - id: preprocess
    command: ./preprocess_data.sh
    gpu_indices: [0, 1, 2, 3]
    run_together: false

  - id: training
    command: ./train_model.sh
    gpu_indices: [0, 1]
    run_together: true
```
Training waits until preprocessing completes.

### Scenario 3: Resource Overlap with Warnings
```yaml
tasks:
  - id: task_a
    gpu_indices: [0, 1]
    run_together: true

  - id: task_b
    gpu_indices: [1, 2]  # Overlaps GPU 1
    run_together: true
```
Both tasks run with warning about GPU 1 conflict.

## Error Handling

### YAML Validation
- Syntax errors are displayed without crashing the system
- Invalid task definitions are rejected with detailed error messages
- System continues operating with current task queue

### Process Failures
- Task failures are logged but don't affect other tasks
- Exit codes are captured and logged
- System continues monitoring remaining tasks

### Resource Conflicts
- GPU overlaps generate warnings but allow execution
- Missing log directories are automatically created
- File permission errors are handled gracefully

## Monitoring and Debugging

### Log Files
- Each task writes to its specified log file
- System logs internal operations to stdout
- Execution history maintains complete audit trail

### Process Monitoring
- Real-time PID tracking for all running tasks
- Automatic detection of task completion
- Resource usage monitoring through occupation script

### Status Reporting
- Live status updates via `status` command
- GPU allocation visualization
- Task queue and execution state display

## Platform Integration

### Deep Learning Platform Requirements
- Designed for platforms without SSH access
- Maintains minimum GPU utilization to prevent termination
- Persistent operation bypasses platform scheduling

### Resource Management
- Automatic GPU environment variable setting
- Process group management prevents resource leaks
- Graceful cleanup on shutdown signals

## Dependencies

- Python 3.6+
- PyYAML library
- Standard library modules: subprocess, threading, signal, datetime
- CUDA-compatible environment for GPU operations

## Installation

1. **Clone or download the system**:
   ```bash
   # All files included in this directory
   ```

2. **Install dependencies**:
   ```bash
   pip install PyYAML
   ```

3. **Make scripts executable**:
   ```bash
   chmod +x scripts/*.sh
   chmod +x gpu_occupation.sh
   ```

4. **Configure your tasks**:
   ```bash
   # Edit tasks.yaml with your specific tasks
   ```

5. **Start the system**:
   ```bash
   python3 gpu_resource_manager.py
   ```

## Troubleshooting

### Common Issues

1. **YAML parsing errors**:
   - Check file syntax with online YAML validator
   - Ensure proper indentation (spaces, not tabs)
   - Verify all required fields are present

2. **Process not terminating**:
   - Check if scripts handle signals properly
   - Use `kill_all` command to force termination
   - Restart system if processes become unresponsive

3. **GPU not recognized**:
   - Verify CUDA_VISIBLE_DEVICES is being set correctly
   - Check GPU indices are valid for your system
   - Ensure occupation script works with your GPU setup

4. **Log file issues**:
   - Verify write permissions for log directories
   - Check disk space availability
   - Ensure parent directories exist

### Performance Optimization

- Use separate GPUs for concurrent tasks to avoid conflicts
- Set appropriate sleep intervals in occupation script
- Monitor system resources during heavy task loads
- Use absolute paths for all scripts and log files

## System Requirements

- **Hardware**: NVIDIA GPUs with CUDA support
- **OS**: Linux/Unix with process group support
- **Python**: 3.6+ with PyYAML
- **Storage**: Sufficient space for task logs and history
- **Permissions**: Ability to create processes and files

## Security Considerations

- All task scripts run with current user permissions
- No privilege escalation or system modifications
- Process isolation through separate process groups
- Log files may contain sensitive training data - secure appropriately

This system provides a complete solution for managing GPU resources on restrictive deep learning platforms while maintaining full control over task scheduling and execution.