# GPU Resource Manager - Complete Usage Guide

## Control Method

📁 **File-Based Mode**: Signal file control for all environments

## Table of Contents
1. [Quick Start](#quick-start)
2. [Control Method Selection](#control-method-selection)
3. [Installation & Setup](#installation--setup)
4. [Configuration](#configuration)
5. [Command Reference](#command-reference)
6. [Task Management](#task-management)
7. [Advanced Usage](#advanced-usage)
8. [Troubleshooting](#troubleshooting)
9. [Best Practices](#best-practices)

## Quick Start

### 📁 File-Based Mode
```bash
# Start the system
python3 gpu_resource_manager.py

# Control via signal files
echo "timestamp: $(date -Iseconds)" > control/status.request
cat control/status.output

echo "timestamp: $(date -Iseconds)" > control/reload.signal
echo "task_id: job_name" > control/kill_task_job_name.signal
```

```

## Control Method Selection

### 📁 **Use File-Based Mode When:**
- Deploying on training platforms
- No terminal access available
- System runs unattended
- Platform restrictions prevent stdin/stdout interaction
- Need programmatic control via scripts



## Installation & Setup

### Prerequisites
```bash
# Required Python version
python3 --version  # Python 3.6 or higher

# Install dependencies
pip install PyYAML

# Verify CUDA environment (if available)
nvidia-smi
```

### File Requirements

**Required Files:**
- `control/tasks.yaml` - Task configuration file
- Task scripts in `scripts/` directory
- `gpu_resource_manager.py`

### Directory Structure Setup

### Prerequisites
```bash
# Required Python version
python3 --version  # Python 3.6 or higher

# Install dependencies
pip install PyYAML

# Verify CUDA environment (if available)
nvidia-smi
```

### Directory Structure Setup
```bash
# Create subdirectories
mkdir -p control scripts logs
```

### Initial Configuration
1. **Copy the main script**: `gpu_resource_manager.py`
2. **Create initial tasks.yaml** (example provided)
3. **Prepare task scripts** in `scripts/` directory
4. **Ensure log directory** exists and is writable

## Configuration

### Primary Configuration File: `control/tasks.yaml`

#### Complete Task Definition
```yaml
tasks:
  - id: unique_task_identifier          # Required: Unique string identifier
    command: /absolute/path/to/script.sh # Required: Full path to executable
    gpu_indices: [0, 1, 2, 3]           # Required: List of GPU card indices
    log_file: /path/to/task.log          # Required: Full path to log file
    run_together: true                   # Required: true=concurrent, false=sequential
    status: pending                      # Required: pending/running/completed
```

#### Field Descriptions

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | ✅ | Unique identifier for task management and killing |
| `command` | string | ✅ | Absolute path to script or command to execute |
| `gpu_indices` | list[int] | ✅ | GPU card indices (0-7) to assign to task |
| `log_file` | string | ✅ | Absolute path where task output will be logged |
| `run_together` | boolean | ✅ | `true`: can run with other concurrent tasks<br>`false`: must run alone |
| `status` | string | ✅ | Current task state: `pending`/`running`/`completed` |

### Task Execution Rules

#### Concurrent Tasks (`run_together: true`)
```yaml
# These tasks can run simultaneously
- id: model_training_a
  run_together: true
  gpu_indices: [0, 1]

- id: model_training_b
  run_together: true
  gpu_indices: [2, 3]

- id: inference_job
  run_together: true
  gpu_indices: [4, 5]
```

**Execution Behavior:**
- Can start while other concurrent tasks are running
- Cannot start if any sequential task is running
- GPU conflicts generate warnings but allow execution

#### Sequential Tasks (`run_together: false`)
```yaml
# This task must run alone
- id: data_preprocessing
  run_together: false
  gpu_indices: [0, 1, 2, 3, 4, 5, 6, 7]
```

**Execution Behavior:**
- Must wait for ALL running tasks to complete before starting
- No other tasks can start while sequential task is running
- Typically used for resource-intensive preprocessing

### GPU Assignment Examples

#### Non-Overlapping GPUs (Recommended)
```yaml
tasks:
  - id: task_a
    gpu_indices: [0, 1]        # Uses GPUs 0,1
  - id: task_b
    gpu_indices: [2, 3]        # Uses GPUs 2,3
  - id: task_c
    gpu_indices: [4, 5, 6, 7]  # Uses GPUs 4,5,6,7
```

#### Overlapping GPUs (With Warnings)
```yaml
tasks:
  - id: task_a
    gpu_indices: [0, 1, 2]     # Uses GPUs 0,1,2
  - id: task_b
    gpu_indices: [1, 2, 3]     # Overlaps GPUs 1,2 - will generate warning
```

### Environment Variables

The system automatically sets `CUDA_VISIBLE_DEVICES` for each task:

```bash
# For task with gpu_indices: [0, 2, 5]
export CUDA_VISIBLE_DEVICES=0,2,5

# Task script sees GPUs as indices 0,1,2 (remapped)
# Actual GPUs used: 0,2,5 (original indices)
```

## Command Reference (File-Based)

#### 1. `status.request` - System Status
```
echo "timestamp: $(date -Iseconds)" > control/status.request
cat control/status.output
```

**Output Sections:**
- **Tasks file**: Currently loaded configuration file
- **Total tasks**: Number of tasks in configuration
- **Running tasks**: Currently executing tasks with PIDs and GPU assignments
- **Pending tasks**: Tasks waiting to execute with concurrency settings
- **GPU occupation**: Status of resource occupation process

#### 2. `reload.signal` - Configuration Reload
```
echo "timestamp: $(date -Iseconds)" > control/reload.signal
```

**Behavior:**
- Reloads and validates YAML configuration
- Preserves currently running tasks
- Adds new pending tasks to queue
- Reports validation errors without crashing

**Error Example:**
```
> reload
YAML parsing error: while parsing a flow sequence
  in "tasks.yaml", line 4, column 18
expected ',' or ']', but got '?'
  in "tasks.yaml", line 6, column 5
Failed to reload tasks
```

#### 3. `kill.signal` - Terminate Specific Task (preferred)
```
echo "task_id: training_model_a" > control/kill.signal
```

#### Legacy: `kill_task_<task_id>.signal`
```
echo > control/kill_task_training_model_a.signal
```

**Behavior:**
- Attempts graceful termination (SIGTERM) with 10-second timeout
- Falls back to force termination (SIGKILL) if needed
- Updates task status to "completed"
- Logs execution history with termination timestamp
- Removes task from running list

**Error Cases:**
```
> kill nonexistent_task
Task nonexistent_task is not currently running
```

#### 4. `kill_all.signal` - Terminate All Tasks
```
echo "timestamp: $(date -Iseconds)" > control/kill_all.signal
```

**Behavior:**
- Iterates through all currently running tasks
- Applies same termination logic as individual kill
- Updates all task statuses and history
- Clears running task list

#### 5. `shutdown.signal` - Graceful Shutdown
```
echo "timestamp: $(date -Iseconds)" > control/shutdown.signal
```

**Shutdown Sequence:**
1. Signals shutdown to monitoring thread
2. Terminates all running tasks
3. Stops GPU occupation process
4. Cleans up resources
5. Exits gracefully

#### 6. `help` - Command Help
```
> help
Available commands:
  reload         - Reload tasks from YAML file
  kill <task_id> - Kill specific running task
  kill_all       - Kill all running tasks
  status         - Show current system status
  quit           - Graceful shutdown
```

## Task Management

### Task Lifecycle

```mermaid
graph TD
    A[Task Defined in YAML] --> B[Status: pending]
    B --> C{Can Start?}
    C -->|Yes| D[Status: running]
    C -->|No| E[Wait in Queue]
    E --> C
    D --> F{Task Complete?}
    F -->|Natural End| G[Status: completed]
    F -->|Killed| H[Status: completed]
    F -->|Still Running| F
    G --> I[Log to History]
    H --> I
```

### Task Scheduling Logic

#### Decision Tree for Task Starting
```
Can task start?
├── Is task status 'pending'?
│   ├── No → Cannot start
│   └── Yes → Continue
├── Is task concurrent (run_together: true)?
│   ├── Yes → Are any sequential tasks running?
│   │   ├── Yes → Cannot start (wait for sequential to finish)
│   │   └── No → Can start
│   └── No → Is task sequential (run_together: false)?
│       └── Are ANY other tasks running?
│           ├── Yes → Cannot start (wait for all to finish)
│           └── No → Can start
```

#### Execution Examples

**Scenario 1: All Concurrent Tasks**
```yaml
tasks:
  - {id: task_a, run_together: true, gpu_indices: [0,1]}
  - {id: task_b, run_together: true, gpu_indices: [2,3]}
  - {id: task_c, run_together: true, gpu_indices: [4,5]}
```
**Result**: All tasks start simultaneously

**Scenario 2: Sequential Task First**
```yaml
tasks:
  - {id: preprocess, run_together: false, gpu_indices: [0,1,2,3]}
  - {id: task_a, run_together: true, gpu_indices: [0,1]}
  - {id: task_b, run_together: true, gpu_indices: [2,3]}
```
**Result**:
1. `preprocess` starts alone
2. After `preprocess` completes, `task_a` and `task_b` start together

**Scenario 3: Sequential Task Interrupts**
```yaml
tasks:
  - {id: task_a, run_together: true, gpu_indices: [0,1]}
  - {id: task_b, run_together: true, gpu_indices: [2,3]}
  - {id: preprocess, run_together: false, gpu_indices: [0,1,2,3]}
```
**Result**:
1. `task_a` and `task_b` start together
2. `preprocess` waits for both to complete
3. `preprocess` starts alone after both finish

### GPU Conflict Handling

#### Warning Generation
```
Warning: Task model_b conflicts with model_a on GPUs [1, 2]
```

**Conflict Detection Logic:**
```python
def check_conflicts(new_task, running_tasks):
    conflicts = []
    new_gpus = set(new_task.gpu_indices)

    for running_task in running_tasks:
        running_gpus = set(running_task.gpu_indices)
        overlap = new_gpus.intersection(running_gpus)
        if overlap:
            conflicts.append(f"Task {new_task.id} conflicts with {running_task.id} on GPUs {list(overlap)}")

    return conflicts
```

**Resolution Strategy:**
- Generate warnings for user awareness
- Allow execution to proceed (user responsibility)
- Some workloads can safely share GPUs
- User can modify configuration if conflicts are problematic

### Process Management

#### Process Group Creation
```python
# Each task runs in its own process group
process = subprocess.Popen(
    task.command,
    shell=True,
    env=env,
    stdout=log_file,
    stderr=subprocess.STDOUT,
    preexec_fn=os.setsid  # Creates new process group
)
```

#### Termination Strategy
```python
def kill_task(task_id):
    # 1. Graceful termination
    os.killpg(os.getpgid(process.pid), signal.SIGTERM)

    # 2. Wait with timeout
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        # 3. Force termination
        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
        process.wait()
```

### Logging System

#### Individual Task Logs
Each task writes to its specified log file:
```bash
# Example: model_a.log
Starting Model A training...
Using GPUs: 0,1,2,3
Timestamp: Sun 28 Sep 2025 10:22:02 CST
Epoch 1: Training model A...
Epoch 2: Training model A...
...
Model A training completed successfully!
Final timestamp: Sun 28 Sep 2025 10:23:29 CST
```

#### Execution History
Complete audit trail in `execution_history.yaml`:
```yaml
execution_history:
- command: /path/to/scripts/train_model_a.sh
  completed_at: '2025-09-28T10:22:12.009501'
  gpu_indices: [0, 1, 2, 3]
  id: training_model_a
  log_file: /path/to/logs/model_a.log
  started_at: '2025-09-28T10:22:02.071963'
  status: completed
```

#### Status Persistence
Task status updates are saved back to original YAML:
```yaml
# Original
status: pending

# After execution starts
status: running

# After completion
status: completed
```

## Advanced Usage

### Custom Task Scripts

#### Script Requirements
1. **Executable**: Must have execute permissions (`chmod +x`)
2. **Shebang**: Should include proper shebang (`#!/bin/bash`)
3. **GPU Awareness**: Should use `$CUDA_VISIBLE_DEVICES` environment variable
4. **Output**: All output will be captured in specified log file

#### Example Task Script
```bash
#!/bin/bash
# Advanced training script example

set -e  # Exit on any error

echo "=== Training Job Started ==="
echo "Job ID: $1"
echo "Using GPUs: $CUDA_VISIBLE_DEVICES"
echo "Timestamp: $(date)"
echo "Host: $(hostname)"
echo "Working Directory: $(pwd)"

# Validate GPU availability
if command -v nvidia-smi &> /dev/null; then
    echo "GPU Status:"
    nvidia-smi --query-gpu=index,name,utilization.gpu --format=csv
else
    echo "nvidia-smi not available - running in simulation mode"
fi

# Main training loop
EPOCHS=${2:-100}
for epoch in $(seq 1 $EPOCHS); do
    echo "Epoch $epoch/$EPOCHS: $(date)"

    # Simulate training work
    python3 -c "
import time
import random
print(f'  Training batch processing...')
time.sleep(2)  # Simulate work
accuracy = random.uniform(0.85, 0.99)
loss = random.uniform(0.01, 0.15)
print(f'  Accuracy: {accuracy:.4f}, Loss: {loss:.4f}')
"

    # Check for early termination signal
    if [ -f "stop_training.flag" ]; then
        echo "Early termination requested"
        rm -f "stop_training.flag"
        break
    fi
done

echo "=== Training Job Completed ==="
echo "Final timestamp: $(date)"
```

### Configuration Patterns

#### Development Environment
```yaml
# Fast iteration with short tasks
tasks:
  - id: quick_test_a
    command: /path/to/quick_test.sh
    gpu_indices: [0]
    log_file: /tmp/test_a.log
    run_together: true
    status: pending

  - id: quick_test_b
    command: /path/to/quick_test.sh
    gpu_indices: [1]
    log_file: /tmp/test_b.log
    run_together: true
    status: pending
```

#### Production Environment
```yaml
# Long-running production jobs
tasks:
  - id: production_model_v1
    command: /opt/ml/scripts/train_production_v1.sh
    gpu_indices: [0, 1, 2, 3]
    log_file: /var/log/ml/production_v1.log
    run_together: false  # Exclusive execution
    status: pending

  - id: inference_service
    command: /opt/ml/scripts/start_inference.sh
    gpu_indices: [4, 5, 6, 7]
    log_file: /var/log/ml/inference.log
    run_together: true
    status: pending
```

#### Batch Processing Pipeline
```yaml
# Sequential pipeline stages
tasks:
  - id: data_validation
    command: /path/to/validate_data.sh
    gpu_indices: [0]
    log_file: /logs/validation.log
    run_together: false
    status: pending

  - id: data_preprocessing
    command: /path/to/preprocess.sh
    gpu_indices: [0, 1, 2, 3]
    log_file: /logs/preprocessing.log
    run_together: false
    status: pending

  - id: model_training
    command: /path/to/train.sh
    gpu_indices: [0, 1, 2, 3, 4, 5, 6, 7]
    log_file: /logs/training.log
    run_together: false
    status: pending
```

### GPU Occupation Customization

The system auto-generates `gpu_occupation.sh`, but you can customize it:

```bash
#!/bin/bash
# Custom GPU occupation script

echo "Starting custom GPU occupation..."

# Option 1: Use a simple CUDA program
python3 -c "
import time
import subprocess

# Keep minimal GPU utilization
while True:
    try:
        # Run a lightweight CUDA operation
        result = subprocess.run([
            'python3', '-c',
            'import torch; torch.cuda.is_available() and torch.zeros(1).cuda()'
        ], capture_output=True, timeout=5)
        time.sleep(30)  # Check every 30 seconds
    except:
        time.sleep(10)  # Fallback interval
"

# Option 2: Use nvidia-ml-py for more control
# python3 -c "
# import pynvml
# import time
#
# pynvml.nvmlInit()
# device_count = pynvml.nvmlDeviceGetCount()
#
# while True:
#     for i in range(device_count):
#         handle = pynvml.nvmlDeviceGetHandleByIndex(i)
#         # Light operations to maintain minimal utilization
#     time.sleep(60)
# "
```

### Integration with External Systems

#### Slack Notifications
```bash
#!/bin/bash
# Enhanced script with notifications

# Your main task logic here
python3 train_model.py

# Send completion notification
if [ $? -eq 0 ]; then
    curl -X POST -H 'Content-type: application/json' \
        --data '{"text":"Training completed successfully!"}' \
        YOUR_SLACK_WEBHOOK_URL
else
    curl -X POST -H 'Content-type: application/json' \
        --data '{"text":"Training failed!"}' \
        YOUR_SLACK_WEBHOOK_URL
fi
```

#### Checkpoint Management
```bash
#!/bin/bash
# Script with checkpoint support

CHECKPOINT_DIR="/checkpoints/$(date +%Y%m%d_%H%M%S)"
mkdir -p "$CHECKPOINT_DIR"

# Main training with checkpointing
python3 train_model.py \
    --checkpoint-dir "$CHECKPOINT_DIR" \
    --save-interval 100 \
    --resume-from-latest

# Archive completed checkpoints
if [ $? -eq 0 ]; then
    tar -czf "${CHECKPOINT_DIR}.tar.gz" "$CHECKPOINT_DIR"
    echo "Checkpoints archived to ${CHECKPOINT_DIR}.tar.gz"
fi
```

### Monitoring and Debugging

#### Real-time Monitoring
```bash
watch -n 5 'cat control/current_status.txt'
```

#### Log Tailing
```bash
# Monitor all logs simultaneously
tail -f logs/*.log

# Monitor specific task
tail -f logs/training_model_a.log
```

#### Process Monitoring
```bash
# Monitor GPU usage
nvidia-smi -l 1

# Monitor system resources
htop

# Monitor specific processes
ps aux | grep python3
```

## Troubleshooting

### Common Issues and Solutions

#### 1. YAML Parsing Errors
**Problem:**
```
YAML parsing error: while parsing a flow sequence
  in "tasks.yaml", line 4, column 18
expected ',' or ']', but got '?'
```

**Solutions:**
- Validate YAML syntax with online validator
- Check for missing brackets, quotes, or colons
- Ensure consistent indentation (spaces, not tabs)
- Verify all required fields are present

#### 2. Tasks Not Starting
**Problem:** Tasks remain in "pending" status indefinitely

**Debugging Steps:**
```bash
# Check task configuration
> status

# Verify script permissions
chmod +x scripts/your_script.sh

# Test script manually
bash scripts/your_script.sh

# Check for sequential task blocking
# Look for run_together: false tasks that might be waiting
```

**Common Causes:**
- Script not executable
- Sequential task waiting for others to complete
- Invalid script path
- Missing dependencies in script

#### 3. Process Not Terminating
**Problem:** Tasks don't respond to kill commands

**Solutions:**
```bash
# Force kill from system level
ps aux | grep your_script
kill -9 PID

# Restart the resource manager
> quit
python3 gpu_resource_manager.py

# Check for zombie processes
ps aux | grep defunct
```

#### 4. Log File Issues
**Problem:** Log files not created or empty

**Solutions:**
```bash
# Check directory permissions
ls -la logs/
chmod 755 logs/

# Create log directory
mkdir -p logs/

# Test log file creation
touch logs/test.log
```

#### 5. GPU Environment Issues
**Problem:** Scripts don't see assigned GPUs

**Solutions:**
```bash
# Verify CUDA installation
nvidia-smi

# Test GPU assignment manually
CUDA_VISIBLE_DEVICES=0,1 nvidia-smi

# Add debug output to scripts
echo "GPUs available: $CUDA_VISIBLE_DEVICES"
```

### Performance Issues

#### High Memory Usage
**Symptoms:** System becoming slow or unresponsive

**Solutions:**
- Reduce number of concurrent tasks
- Monitor memory usage: `htop` or `top`
- Check for memory leaks in task scripts
- Increase system swap space

#### Slow Task Starting
**Symptoms:** Long delay between task scheduling and execution

**Solutions:**
- Reduce monitoring thread sleep interval
- Check system load: `uptime`
- Verify disk I/O performance
- Check network dependencies in scripts

### Debug Mode

#### Enable Verbose Logging
Modify the main script to add debug output:
```python
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Add to various methods
logger.debug(f"Starting task {task.id} with command: {task.command}")
logger.debug(f"GPU indices: {task.gpu_indices}")
logger.debug(f"Process PID: {process.pid}")
```

#### System State Inspection
```python
# Add debug command to the command loop
elif cmd == "debug":
    print(f"Running tasks: {len(self.running_tasks)}")
    for task_id, task in self.running_tasks.items():
        print(f"  {task_id}: PID {task.process.pid if task.process else 'None'}")
    print(f"Total tasks loaded: {len(self.tasks)}")
    print(f"Occupation process: {self.occupation_process}")
```

## Best Practices

### Configuration Management
1. **Version Control**: Keep `tasks.yaml` in version control
2. **Backup**: Regularly backup execution history
3. **Validation**: Test YAML changes before production deployment
4. **Documentation**: Comment complex task configurations

### Resource Management
1. **GPU Allocation**: Avoid unnecessary GPU overlaps
2. **Memory Planning**: Consider GPU memory requirements
3. **Monitoring**: Regularly check system resource usage
4. **Cleanup**: Remove old log files periodically

### Script Development
1. **Error Handling**: Include proper error handling in scripts
2. **Logging**: Add detailed logging to task scripts
3. **Testing**: Test scripts independently before adding to queue
4. **Dependencies**: Document and check all script dependencies

### Security Considerations
1. **Path Security**: Use absolute paths to prevent injection
2. **Permissions**: Set minimal required permissions
3. **Isolation**: Run tasks with appropriate user permissions
4. **Validation**: Validate all inputs and configurations

### Production Deployment
1. **Monitoring**: Set up external monitoring for the system
2. **Alerts**: Configure alerts for system failures
3. **Backup**: Implement automated backup of configurations and logs
4. **Updates**: Plan for system updates and maintenance windows

This comprehensive usage guide covers all aspects of the GPU Resource Manager system, from basic usage to advanced configuration and troubleshooting. Use this as your complete reference for operating the system effectively.