#!/usr/bin/env python3
"""
GPU Resource Manager - File-Based Control System
Maintains persistent GPU occupation while managing task queue
Uses file-based signaling for platform deployment without terminal access
"""

import os
import sys
import yaml
import subprocess
import threading
import time
import signal
import glob
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from pathlib import Path


# Valid task status values
VALID_TASK_STATUS = {"pending", "running", "completed"}

# Required task fields (only these two are mandatory)
MINIMAL_REQUIRED_FIELDS = {"id", "command"}

# All possible task fields
ALL_TASK_FIELDS = {"id", "command", "gpu_indices", "log_file", "run_together", "status"}


@dataclass
class Task:
    id: str
    command: str
    gpu_indices: List[int]
    log_file: str
    run_together: bool
    status: str = "pending"
    process: Optional[subprocess.Popen] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


class GPUResourceManager:
    def __init__(self, control_dir: str = "control"):
        self.control_dir = control_dir
        self.yaml_file = os.path.join(control_dir, "tasks.yaml")
        self.history_file = os.path.join(control_dir, "execution_history.yaml")
        self.system_log = os.path.join(control_dir, "system.log")
        self.tasks: List[Task] = []
        self.running_tasks: Dict[str, Task] = {}
        self.occupation_process: Optional[subprocess.Popen] = None
        self.shutdown_requested = False

        # Create control directory for all files
        os.makedirs(self.control_dir, exist_ok=True)

        # Create fallback occupation script if it doesn't exist (for backup)
        self.occupation_script = os.path.join(control_dir, "gpu_occupation_fallback.sh")
        self._create_occupation_script()

        # Load initial tasks
        self.reload_tasks()

        # Start monitoring threads
        self.monitor_thread = threading.Thread(target=self._monitor_tasks, daemon=True)
        self.monitor_thread.start()

        self.signal_thread = threading.Thread(target=self._monitor_signals, daemon=True)
        self.signal_thread.start()

        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        # Write initial status
        self._write_status()

    def _create_occupation_script(self):
        """Create a fallback GPU occupation script if the main occupier fails"""
        if not os.path.exists(self.occupation_script):
            # Fallback to simple script if the advanced occupier fails
            script_content = f"""#!/bin/bash
# Fallback GPU occupation script - basic utilization maintenance
# This is used only if the main configurable occupier fails

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

# Try to use the configurable occupier first
if python3 "$PROJECT_DIR/scripts/gpu_occupier.py" --target-util 10 --log-level ERROR 2>/dev/null; then
    exit 0
fi

# Fallback to simple nvidia-smi based occupation
python3 -c "
import time
import subprocess
import signal
import sys

def signal_handler(sig, frame):
    print('Fallback GPU occupation terminated.')
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

print('Starting fallback GPU occupation...')
try:
    while True:
        # Simple GPU query to maintain minimal activity
        for gpu_id in range(8):
            try:
                subprocess.run(['nvidia-smi', '-i', str(gpu_id), '--query-gpu=utilization.gpu',
                              '--format=csv,noheader,nounits'], capture_output=True, timeout=1)
            except:
                pass
        time.sleep(5)
except KeyboardInterrupt:
    print('Fallback occupation terminated.')
"
"""
            with open(self.occupation_script, 'w') as f:
                f.write(script_content)
            os.chmod(self.occupation_script, 0o755)

    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        print(f"\nReceived signal {signum}, initiating graceful shutdown...")
        self._write_log(f"Received shutdown signal {signum}")
        self.shutdown()

    def _write_log(self, message: str, add_separator: bool = False):
        """Write log message to system log file"""
        timestamp = datetime.now().isoformat()
        log_message = f"[{timestamp}] {message}\n"

        with open(self.system_log, "a") as f:
            if add_separator:
                f.write("\n" + "="*80 + "\n")
            f.write(log_message)

        # Also print to stdout for platform logging
        if add_separator:
            print("\n" + "="*80)
        print(f"[{timestamp}] {message}")

    def _monitor_signals(self):
        """Monitor control directory for signal files"""
        self._write_log("Signal monitoring thread started")

        while not self.shutdown_requested:
            try:
                self._process_signal_files()
                time.sleep(1)  # Check every second
            except Exception as e:
                self._write_log(f"Error in signal monitoring: {e}")
                time.sleep(5)

    def _process_signal_files(self):
        """Process all signal files in control directory"""
        signal_files = glob.glob(f"{self.control_dir}/*.signal") + glob.glob(f"{self.control_dir}/*.request")

        for signal_file in signal_files:
            try:
                self._process_single_signal_file(signal_file)
            except Exception as e:
                self._write_log(f"Error processing signal file {signal_file}: {e}")

    def _process_single_signal_file(self, signal_file: str):
        """Process a single signal file"""
        filename = os.path.basename(signal_file)

        try:
            # Read signal file content
            with open(signal_file, 'r') as f:
                content = f.read().strip()

            # Parse signal type and execute command
            if filename == "reload.signal":
                self._handle_reload_signal(content)
            elif filename == "status.request":
                self._handle_status_request(content)
            elif filename == "kill_all.signal":
                self._handle_kill_all_signal(content)
            elif filename == "kill.signal":
                # Generic kill signal; read task_id from content
                task_id = None
                lines = [line.strip() for line in content.split('\n') if line.strip()]
                for line in lines:
                    if line.startswith("task_id:"):
                        task_id = line.split(":", 1)[1].strip()
                        break
                if not task_id and lines:
                    # Fallback: use the first non-empty line as task_id
                    task_id = lines[0]
                if task_id:
                    self._handle_kill_task_signal(task_id, content)
                else:
                    self._write_log("kill.signal missing task_id; ignoring")
            elif filename.startswith("kill_task_") and filename.endswith(".signal"):
                task_id = filename[10:-7]  # Remove "kill_task_" and ".signal"
                self._handle_kill_task_signal(task_id, content)
            elif filename == "shutdown.signal":
                self._handle_shutdown_signal(content)
            else:
                self._write_log(f"Unknown signal file: {filename}")

            # Remove processed signal file
            os.remove(signal_file)

        except Exception as e:
            self._write_log(f"Error processing signal file {signal_file}: {e}")

    def _handle_reload_signal(self, content: str):
        """Handle reload signal"""
        self._write_log("Processing reload signal")

        if self.reload_tasks():
            self._write_log("Tasks reloaded successfully")
            self._write_status()
        else:
            self._write_log("Failed to reload tasks")

    def _handle_status_request(self, content: str):
        """Handle status request"""
        self._write_log("Processing status request")

        # Parse request format (optional)
        format_type = "detailed"
        if "format:" in content:
            lines = content.split('\n')
            for line in lines:
                if line.startswith("format:"):
                    format_type = line.split(":", 1)[1].strip()
                    break

        status = self.get_status()

        # Write status to output file
        status_file = f"{self.control_dir}/status.output"
        with open(status_file, 'w') as f:
            f.write(f"# Status generated at {datetime.now().isoformat()}\n")
            f.write(status)

        self._write_log(f"Status written to {status_file}")

    def _handle_kill_all_signal(self, content: str):
        """Handle kill all signal"""
        self._write_log("Processing kill_all signal")

        killed_count = 0
        task_ids = list(self.running_tasks.keys())

        for task_id in task_ids:
            if self.kill_task(task_id):
                killed_count += 1

        self._write_log(f"Killed {killed_count} tasks")
        self._write_status()

    def _handle_kill_task_signal(self, task_id: str, content: str):
        """Handle kill specific task signal"""
        self._write_log(f"Processing kill signal for task {task_id}")

        if self.kill_task(task_id):
            self._write_log(f"Successfully killed task {task_id}")
        else:
            self._write_log(f"Failed to kill task {task_id} (not running)")

        self._write_status()

    def _handle_shutdown_signal(self, content: str):
        """Handle shutdown signal"""
        self._write_log("Processing shutdown signal")
        self.shutdown_requested = True

    def _write_status(self):
        """Write current status to status file"""
        try:
            status = self.get_status()
            status_file = f"{self.control_dir}/current_status.txt"

            with open(status_file, 'w') as f:
                f.write(f"# Status updated at {datetime.now().isoformat()}\n")
                f.write(status)

        except Exception as e:
            self._write_log(f"Error writing status: {e}")

    def _get_available_gpus(self) -> List[int]:
        """Detect available GPUs on the system"""
        try:
            # Try to detect GPUs using nvidia-smi
            result = subprocess.run(['nvidia-smi', '--query-gpu=index', '--format=csv,noheader,nounits'],
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                gpu_indices = [int(line.strip()) for line in result.stdout.strip().split('\n') if line.strip()]
                return gpu_indices if gpu_indices else [0]  # Default to GPU 0 if detection fails
        except (subprocess.TimeoutExpired, FileNotFoundError, ValueError):
            pass

        # Fallback: assume 8 GPUs (common for many setups)
        return list(range(8))

    def _apply_task_defaults(self, task_data: dict) -> dict:
        """Apply smart defaults to task data"""
        completed_task = task_data.copy()

        # Default GPU indices: all available GPUs
        if 'gpu_indices' not in completed_task:
            completed_task['gpu_indices'] = self._get_available_gpus()

        # Default log file: logs/{task_id}.log
        if 'log_file' not in completed_task:
            log_dir = os.path.join(os.getcwd(), 'logs')
            completed_task['log_file'] = os.path.join(log_dir, f"{task_data['id']}.log")

        # Default run_together: false (sequential execution)
        if 'run_together' not in completed_task:
            completed_task['run_together'] = False

        # Default status: pending
        if 'status' not in completed_task:
            completed_task['status'] = 'pending'

        return completed_task

    def _validate_task_data(self, task_data: dict, task_index: int) -> tuple[bool, str]:
        """Validate task data structure and values"""
        try:
            # Check for minimal required fields
            missing_fields = MINIMAL_REQUIRED_FIELDS - set(task_data.keys())
            if missing_fields:
                return False, f"Missing required fields: {missing_fields}"

            # Validate task ID
            task_id = task_data.get('id')
            if not isinstance(task_id, str) or not task_id.strip():
                return False, f"Task ID must be a non-empty string"

            # Validate command
            command = task_data.get('command')
            if not isinstance(command, str) or not command.strip():
                return False, f"Command must be a non-empty string"

            # Validate optional fields if provided
            gpu_indices = task_data.get('gpu_indices')
            if gpu_indices is not None:
                if not isinstance(gpu_indices, list):
                    return False, f"gpu_indices must be a list"
                if not gpu_indices:
                    return False, f"gpu_indices cannot be empty if specified"
                if not all(isinstance(idx, int) and idx >= 0 for idx in gpu_indices):
                    return False, f"All GPU indices must be non-negative integers"

            # Validate log file if provided
            log_file = task_data.get('log_file')
            if log_file is not None:
                if not isinstance(log_file, str) or not log_file.strip():
                    return False, f"log_file must be a non-empty string if specified"

            # Validate run_together if provided
            run_together = task_data.get('run_together')
            if run_together is not None:
                if not isinstance(run_together, bool):
                    return False, f"run_together must be a boolean (true/false) if specified"

            # Validate status if provided - THIS IS THE KEY VALIDATION
            status = task_data.get('status')
            if status is not None:
                if not isinstance(status, str):
                    return False, f"Status must be a string if specified"
                if status not in VALID_TASK_STATUS:
                    return False, f"Invalid status '{status}'. Valid values are: {sorted(VALID_TASK_STATUS)}"

            return True, "Valid"

        except Exception as e:
            return False, f"Validation error: {e}"

    def reload_tasks(self) -> bool:
        """Reload tasks from YAML file with validation"""
        try:
            if not os.path.exists(self.yaml_file):
                self._write_log(f"Warning: {self.yaml_file} not found. Creating empty task file.")
                self._create_empty_yaml()
                return True

            with open(self.yaml_file, 'r') as f:
                data = yaml.safe_load(f)

            if not data or 'tasks' not in data:
                self._write_log("Error: Invalid YAML structure. Expected 'tasks' key.")
                return False

            # Convert to Task objects with validation
            new_tasks = []
            validation_errors = []

            for i, task_data in enumerate(data['tasks']):
                # Apply defaults first
                task_with_defaults = self._apply_task_defaults(task_data)

                # Validate task data with defaults applied
                is_valid, error_msg = self._validate_task_data(task_with_defaults, i)
                if not is_valid:
                    validation_errors.append(f"Task {i+1} ({task_data.get('id', 'unknown')}): {error_msg}")
                    continue

                try:
                    task = Task(**task_with_defaults)
                    new_tasks.append(task)
                except TypeError as e:
                    validation_errors.append(f"Task {i+1} ({task_data.get('id', 'unknown')}): {e}")
                    continue

            # If there were validation errors, log them and don't change the state
            if validation_errors:
                self._write_log("YAML VALIDATION ERRORS - Tasks not loaded:", add_separator=True)
                for error in validation_errors:
                    self._write_log(f"  ❌ {error}")
                self._write_log(f"  📋 Valid status values: {sorted(VALID_TASK_STATUS)}")
                self._write_log("  🔧 Fix these errors and reload to apply changes")
                return False

            self.tasks = new_tasks
            self._write_log(f"Successfully loaded {len(self.tasks)} tasks from {self.yaml_file}")
            return True

        except yaml.YAMLError as e:
            self._write_log(f"YAML parsing error: {e}")
            return False
        except Exception as e:
            self._write_log(f"Error loading tasks: {e}")
            return False

    def _create_empty_yaml(self):
        """Create an empty YAML file with example structure"""
        example_data = {
            'tasks': [
                {
                    'id': 'simple_example',
                    'command': './scripts/my_training.sh'
                    # All other fields are optional and will use smart defaults:
                    # - gpu_indices: All available GPUs (auto-detected)
                    # - log_file: logs/{task_id}.log
                    # - run_together: false (sequential execution)
                    # - status: pending
                },
                {
                    'id': 'custom_example',
                    'command': './scripts/custom_job.sh',
                    'gpu_indices': [0, 1],
                    'run_together': True,
                    'status': 'pending'
                    # log_file will default to logs/custom_example.log
                }
            ]
        }
        with open(self.yaml_file, 'w') as f:
            yaml.dump(example_data, f, default_flow_style=False)

    def _update_task_status(self, task_id: str, status: str, started_at: str = None, completed_at: str = None):
        """Update task status in both memory and YAML file"""
        # Update in memory
        for task in self.tasks:
            if task.id == task_id:
                task.status = status
                if started_at:
                    task.started_at = started_at
                if completed_at:
                    task.completed_at = completed_at
                break

        # Update YAML file
        try:
            data = {'tasks': []}
            for task in self.tasks:
                task_dict = {
                    'id': task.id,
                    'command': task.command,
                    'gpu_indices': task.gpu_indices,
                    'log_file': task.log_file,
                    'run_together': task.run_together,
                    'status': task.status
                }
                data['tasks'].append(task_dict)

            with open(self.yaml_file, 'w') as f:
                yaml.dump(data, f, default_flow_style=False)

        except Exception as e:
            self._write_log(f"Error updating YAML file: {e}")

    def _log_execution_history(self, task: Task):
        """Log task execution to history file"""
        try:
            history_data = {'execution_history': []}

            # Load existing history
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r') as f:
                    existing_data = yaml.safe_load(f)
                    if existing_data and 'execution_history' in existing_data:
                        history_data['execution_history'] = existing_data['execution_history']

            # Add new entry
            history_entry = {
                'id': task.id,
                'command': task.command,
                'gpu_indices': task.gpu_indices,
                'started_at': task.started_at,
                'completed_at': task.completed_at,
                'status': task.status,
                'log_file': task.log_file
            }

            history_data['execution_history'].append(history_entry)

            with open(self.history_file, 'w') as f:
                yaml.dump(history_data, f, default_flow_style=False)

        except Exception as e:
            self._write_log(f"Error logging execution history: {e}")

    def _check_gpu_conflicts(self, new_task: Task) -> List[str]:
        """Check for GPU conflicts with running tasks"""
        conflicts = []
        new_gpus = set(new_task.gpu_indices)

        for running_task in self.running_tasks.values():
            running_gpus = set(running_task.gpu_indices)
            overlap = new_gpus.intersection(running_gpus)
            if overlap:
                conflicts.append(f"Task {new_task.id} conflicts with {running_task.id} on GPUs {list(overlap)}")

        return conflicts

    def _can_start_task(self, task: Task) -> bool:
        """Determine if a task can start based on concurrency rules"""
        if task.status != "pending":
            return False

        # If task can run together with others, just check if it's not sequential
        if task.run_together:
            # Check if any sequential tasks are running
            for running_task in self.running_tasks.values():
                if not running_task.run_together:
                    return False
            return True
        else:
            # Sequential task - can only run if no other tasks are running
            return len(self.running_tasks) == 0

    def _start_task(self, task: Task) -> bool:
        """Start a single task"""
        try:
            # Check for GPU conflicts
            conflicts = self._check_gpu_conflicts(task)
            if conflicts:
                for conflict in conflicts:
                    self._write_log(f"Warning: {conflict}")

            # Kill occupation process if running
            self._stop_occupation()

            # Create log directory if needed
            log_dir = os.path.dirname(task.log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

            # Set up environment with GPU indices
            env = os.environ.copy()
            env['CUDA_VISIBLE_DEVICES'] = ','.join(map(str, task.gpu_indices))

            # Start the process
            with open(task.log_file, 'w') as log_file:
                process = subprocess.Popen(
                    task.command,
                    shell=True,
                    env=env,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    preexec_fn=os.setsid  # Create new process group
                )

            # Update task tracking
            task.process = process
            task.started_at = datetime.now().isoformat()
            self.running_tasks[task.id] = task

            # Update status
            self._update_task_status(task.id, "running", started_at=task.started_at)

            # Log task start with formatting and log file information
            self._write_log(f"TASK STARTED: {task.id}", add_separator=True)
            self._write_log(f"  Process ID: {process.pid}")
            self._write_log(f"  GPU Assignment: {task.gpu_indices}")
            self._write_log(f"  Command: {task.command}")
            self._write_log(f"  Log File: {os.path.abspath(task.log_file)}")
            self._write_log(f"  Started At: {task.started_at}")
            self._write_log(f"  Concurrent Mode: {'Yes' if task.run_together else 'No (Sequential)'}")
            return True

        except Exception as e:
            self._write_log(f"Error starting task {task.id}: {e}")
            return False

    def _monitor_tasks(self):
        """Monitor running tasks and start new ones as appropriate"""
        self._write_log("Task monitoring thread started")

        while not self.shutdown_requested:
            try:
                # Check completed tasks
                completed_tasks = []
                for task_id, task in list(self.running_tasks.items()):
                    if task.process and task.process.poll() is not None:
                        task.completed_at = datetime.now().isoformat()
                        self._update_task_status(task_id, "completed", completed_at=task.completed_at)
                        self._log_execution_history(task)
                        completed_tasks.append(task_id)
                        # Log task completion with formatting
                        self._write_log(f"TASK COMPLETED: {task_id}", add_separator=True)
                        self._write_log(f"  Exit Code: {task.process.returncode}")
                        self._write_log(f"  Duration: {task.started_at} to {task.completed_at}")
                        self._write_log(f"  Log File: {os.path.abspath(task.log_file)}")

                # Remove completed tasks from running list
                for task_id in completed_tasks:
                    del self.running_tasks[task_id]

                # Update status if tasks completed
                if completed_tasks:
                    self._write_status()

                # Try to start new tasks
                for task in self.tasks:
                    if self._can_start_task(task):
                        if self._start_task(task):
                            self._write_status()

                # Start occupation if no tasks running and none pending
                if not self.running_tasks and not any(t.status == "pending" for t in self.tasks):
                    self._start_occupation()

                time.sleep(2)  # Check every 2 seconds

            except Exception as e:
                self._write_log(f"Error in task monitor: {e}")
                time.sleep(5)

    def _start_occupation(self):
        """Start GPU occupation process using the configurable occupier"""
        if self.occupation_process is None or self.occupation_process.poll() is not None:
            try:
                # Get path to the new configurable GPU occupier
                script_dir = os.path.dirname(os.path.abspath(__file__))
                occupier_script = os.path.join(script_dir, "scripts", "gpu_occupier.py")

                # Start the configurable GPU occupier directly
                self.occupation_process = subprocess.Popen(
                    [
                        "python3", occupier_script,
                        "--target-util", "15",  # Low utilization to avoid interfering with real tasks
                        "--log-level", "ERROR"   # Minimal logging to avoid clutter
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    preexec_fn=os.setsid
                )
                self._write_log("Started configurable GPU occupation process to maintain platform resources")
            except Exception as e:
                self._write_log(f"Error starting occupation process: {e}")
                # Fallback to simple script if occupier fails
                self._start_occupation_fallback()

    def _start_occupation_fallback(self):
        """Fallback occupation using simple bash script"""
        try:
            self.occupation_process = subprocess.Popen(
                ["/bin/bash", self.occupation_script],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                preexec_fn=os.setsid
            )
            self._write_log("Started fallback GPU occupation process")
        except Exception as e:
            self._write_log(f"Error starting fallback occupation process: {e}")

    def _stop_occupation(self):
        """Stop GPU occupation process"""
        if self.occupation_process and self.occupation_process.poll() is None:
            try:
                os.killpg(os.getpgid(self.occupation_process.pid), signal.SIGTERM)
                self.occupation_process.wait(timeout=5)
                self._write_log("Stopped GPU occupation process")
            except:
                try:
                    os.killpg(os.getpgid(self.occupation_process.pid), signal.SIGKILL)
                except:
                    pass
            self.occupation_process = None

    def kill_task(self, task_id: str) -> bool:
        """Kill a specific running task"""
        if task_id not in self.running_tasks:
            self._write_log(f"Task {task_id} is not currently running")
            return False

        task = self.running_tasks[task_id]
        try:
            if task.process:
                # Try graceful termination first
                os.killpg(os.getpgid(task.process.pid), signal.SIGTERM)
                try:
                    task.process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    # Force kill if graceful termination fails
                    os.killpg(os.getpgid(task.process.pid), signal.SIGKILL)
                    task.process.wait()

                task.completed_at = datetime.now().isoformat()
                self._update_task_status(task_id, "completed", completed_at=task.completed_at)
                self._log_execution_history(task)

                del self.running_tasks[task_id]
                # Log task termination with formatting
                self._write_log(f"TASK TERMINATED: {task_id}", add_separator=True)
                self._write_log(f"  Terminated At: {task.completed_at}")
                self._write_log(f"  Log File: {os.path.abspath(task.log_file)}")
                return True

        except Exception as e:
            self._write_log(f"Error killing task {task_id}: {e}")
            return False

    def get_status(self) -> str:
        """Get current system status"""
        status_lines = []
        status_lines.append("=== GPU Resource Manager Status ===")
        status_lines.append(f"Tasks file: {self.yaml_file}")
        status_lines.append(f"Total tasks: {len(self.tasks)}")
        status_lines.append(f"Timestamp: {datetime.now().isoformat()}")

        # Running tasks
        status_lines.append(f"\nRunning tasks ({len(self.running_tasks)}):")
        if self.running_tasks:
            for task_id, task in self.running_tasks.items():
                status_lines.append(f"  {task_id}: GPUs {task.gpu_indices}, PID {task.process.pid if task.process else 'N/A'}")
        else:
            status_lines.append("  None")

        # Pending tasks
        pending_tasks = [t for t in self.tasks if t.status == "pending"]
        status_lines.append(f"\nPending tasks ({len(pending_tasks)}):")
        if pending_tasks:
            for task in pending_tasks:
                status_lines.append(f"  {task.id}: GPUs {task.gpu_indices}, concurrent={task.run_together}")
        else:
            status_lines.append("  None")

        # Completed tasks
        completed_tasks = [t for t in self.tasks if t.status == "completed"]
        status_lines.append(f"\nCompleted tasks ({len(completed_tasks)}):")
        if completed_tasks:
            for task in completed_tasks[-5:]:  # Show last 5 completed
                status_lines.append(f"  {task.id}: Completed at {task.completed_at}")
            if len(completed_tasks) > 5:
                status_lines.append(f"  ... and {len(completed_tasks) - 5} more")
        else:
            status_lines.append("  None")

        # Occupation status
        occ_status = "Running" if self.occupation_process and self.occupation_process.poll() is None else "Stopped"
        status_lines.append(f"\nGPU occupation: {occ_status}")

        return "\n".join(status_lines)

    def shutdown(self):
        """Graceful shutdown"""
        # Shutdown banner with formatting
        self._write_log("GPU RESOURCE MANAGER SHUTDOWN", add_separator=True)
        self.shutdown_requested = True

        # Kill all tasks
        task_ids = list(self.running_tasks.keys())
        for task_id in task_ids:
            self.kill_task(task_id)

        # Stop occupation
        self._stop_occupation()

        # Write final status
        self._write_status()

        self._write_log("  Status: Shutdown complete.")
        self._write_log("="*80)

    def run_main_loop(self):
        """Main program loop - just wait for signals"""
        # Startup banner with formatting
        self._write_log("GPU RESOURCE MANAGER STARTUP", add_separator=True)
        self._write_log(f"  Mode: File-Based Control System")
        self._write_log(f"  Control Directory: {os.path.abspath(self.control_dir)}")
        self._write_log(f"  System Log: {os.path.abspath(self.system_log)}")
        self._write_log(f"  Tasks File: {os.path.abspath(self.yaml_file)}")
        self._write_log(f"  History File: {os.path.abspath(self.history_file)}")
        self._write_log("  Status: Monitoring for signal files...")

        # Write usage instructions
        self._write_usage_instructions()

        try:
            while not self.shutdown_requested:
                time.sleep(5)  # Main thread sleeps, monitoring happens in background

        except KeyboardInterrupt:
            self._write_log("Received keyboard interrupt")

        self.shutdown()

    def _write_usage_instructions(self):
        """Write usage instructions to control directory"""
        instructions = """# GPU Resource Manager - File-Based Control

All control files are in this directory. To control the system, create signal files here:

## Available Commands:

1. Request Status:
   echo "timestamp: $(date -Iseconds)" > status.request
   # Check status.output for results

2. Reload Tasks:
   echo "timestamp: $(date -Iseconds)" > reload.signal

3. Kill All Tasks:
   echo "timestamp: $(date -Iseconds)" > kill_all.signal

4. Kill Specific Task:
   echo "task_id: your_task_id" > kill_task_your_task_id.signal

5. Shutdown System:
   echo "timestamp: $(date -Iseconds)" > shutdown.signal

## Control Files:
- tasks.yaml: Task configuration (edit to add/modify tasks)
- current_status.txt: Always contains latest system status
- status.output: Created when status.request is processed
- system.log: Complete system log with timestamps
- execution_history.yaml: Complete execution history

## File Structure:
All control and configuration files are in this single directory.
Signal files are automatically deleted after processing.
"""

        with open(f"{self.control_dir}/USAGE_INSTRUCTIONS.txt", 'w') as f:
            f.write(instructions)


def main():
    """Main entry point"""
    control_dir = sys.argv[1] if len(sys.argv) > 1 else "control"

    try:
        manager = GPUResourceManager(control_dir)
        manager.run_main_loop()
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()