# GPU Resource Manager - System Design & Architecture

## System Architecture

📁 **File-Based Architecture**: Signal file monitoring for platform deployment and local use

## Table of Contents
1. [System Overview](#system-overview)
2. [Architecture Comparison](#architecture-comparison)
3. [Architecture Diagrams](#architecture-diagrams)
4. [Process Flow Diagrams](#process-flow-diagrams)
5. [Component Design](#component-design)
6. [Data Flow](#data-flow)
7. [State Management](#state-management)
8. [Concurrency Model](#concurrency-model)
9. [Error Handling Strategy](#error-handling-strategy)

## System Overview

The GPU Resource Manager provides a single architecture optimized for all deployment scenarios using file-based signaling. The core task management engine is controlled exclusively through files in a control directory.

## Control Characteristics

| Feature | File-Based Mode |
|---------|-----------------|
| **Control Method** | Signal files in `control/` |
| **Deployment** | Local and platform deployment |
| **Terminal Access** | Not required |
| **Interaction** | Polling-based |
| **Platform Compatibility** | Universal |
| **Automation** | Scriptable |
| **User Interface** | File system |
| **Backend** | `gpu_resource_manager.py` |

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    GPU Resource Manager                         │
│                                                                 │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │   Main Thread   │  │ Monitor Thread  │  │ Command Thread  │ │
│  │   (Control)     │  │  (Task Mgmt)    │  │   (stdin I/O)   │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
│           │                     │                     │        │
│           ▼                     ▼                     ▼        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐ │
│  │ Task Management │  │Process Tracking │  │ User Interface  │ │
│  │    System       │  │     System      │  │    System       │ │
│  └─────────────────┘  └─────────────────┘  └─────────────────┘ │
│           │                     │                     │        │
│           └─────────┬───────────┴─────────────────────┘        │
│                     ▼                                          │
│           ┌─────────────────┐                                  │
│           │   Subprocess    │                                  │
│           │   Management    │                                  │
│           └─────────────────┘                                  │
└─────────────────────────────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                    External Processes                           │
│                                                                 │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────┐ │
│  │   Task A    │  │   Task B    │  │   Task C    │  │   GPU   │ │
│  │ (Training)  │  │(Inference)  │  │(Preprocess) │  │ Occupy  │ │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## Architecture Diagrams

### Component Architecture

```mermaid
graph TB
    subgraph "GPU Resource Manager Process"
        A[Main Application] --> B[GPUResourceManager Class]
        B --> C[Task Dataclass]
        B --> D[YAML Parser]
        B --> E[Process Manager]
        B --> F[Command Interface]
        B --> G[Monitor Thread]
        B --> H[Signal Handler]
    end

    subgraph "External Resources"
        I[tasks.yaml]
        J[execution_history.yaml]
        K[Log Files]
        L[Task Scripts]
        M[GPU Occupation Script]
    end

    subgraph "Managed Processes"
        N[Task Process 1]
        O[Task Process 2]
        P[Task Process N]
        Q[GPU Occupation Process]
    end

    D --> I
    D --> J
    E --> N
    E --> O
    E --> P
    E --> Q
    F --> K
    N --> L
    O --> L
    P --> L
    Q --> M
```

### Threading Model

```mermaid
graph LR
    subgraph "Main Thread"
        A[Application Startup] --> B[Initialize Components]
        B --> C[Start Monitor Thread]
        C --> D[Command Loop]
        D --> E[Process Commands]
        E --> D
        D --> F[Shutdown Signal]
        F --> G[Cleanup & Exit]
    end

    subgraph "Monitor Thread (Daemon)"
        H[Monitor Loop] --> I[Check Running Tasks]
        I --> J[Update Task Status]
        J --> K[Start New Tasks]
        K --> L[Manage GPU Occupation]
        L --> M[Sleep 1 Second]
        M --> H
    end

    C --> H
    F --> N[Signal Monitor Thread]
    N --> O[Thread Cleanup]
```

## Process Flow Diagrams

### System Startup Flow

```mermaid
flowchart TD
    A[python3 gpu_resource_manager.py] --> B[Create GPUResourceManager Instance]
    B --> C[Load tasks.yaml]
    C --> D{YAML Valid?}
    D -->|No| E[Create Empty YAML] --> F
    D -->|Yes| F[Parse Tasks]
    F --> G[Create GPU Occupation Script]
    G --> H[Setup Signal Handlers]
    H --> I[Start Monitor Thread]
    I --> J[Print Startup Message]
    J --> K[Enter Command Loop]
    K --> L[Wait for User Input]
```

### Task Execution Flow

```mermaid
flowchart TD
    A[Monitor Thread Checks Tasks] --> B{Any Pending Tasks?}
    B -->|No| C[Check if GPU Occupation Needed]
    B -->|Yes| D[For Each Pending Task]
    D --> E{Can Task Start?}
    E -->|No| F[Continue to Next Task]
    E -->|Yes| G[Check GPU Conflicts]
    G --> H[Stop GPU Occupation]
    H --> I[Set Environment Variables]
    I --> J[Create Log File]
    J --> K[Start Subprocess]
    K --> L[Update Task Status to 'running']
    L --> M[Add to Running Tasks Dict]
    M --> N[Log Start Time]
    N --> O[Continue Monitor Loop]
    F --> P{More Tasks?}
    P -->|Yes| D
    P -->|No| C
    C --> Q{No Running Tasks?}
    Q -->|Yes| R[Start GPU Occupation]
    Q -->|No| S[Continue Monitor Loop]
    R --> S
    O --> S
    S --> T[Sleep 1 Second]
    T --> A
```

### Task Completion Flow

```mermaid
flowchart TD
    A[Monitor Thread Checks Running Tasks] --> B[For Each Running Task]
    B --> C{Process Finished?}
    C -->|No| D[Continue to Next Task]
    C -->|Yes| E[Get Exit Code]
    E --> F[Set Completion Time]
    F --> G[Update Status to 'completed']
    G --> H[Log to Execution History]
    H --> I[Remove from Running Tasks]
    I --> J[Print Completion Message]
    J --> K{More Running Tasks?}
    K -->|Yes| D
    K -->|No| L[Check if GPU Occupation Needed]
    L --> M[Continue Monitor Loop]
    D --> N{More Tasks to Check?}
    N -->|Yes| B
    N -->|No| L
```

### Kill Command Flow

```mermaid
flowchart TD
    A[User Types 'kill task_id'] --> B{Task ID in Running Tasks?}
    B -->|No| C[Print 'Task not running']
    B -->|Yes| D[Get Process Object]
    D --> E[Send SIGTERM to Process Group]
    E --> F[Wait 10 Seconds]
    F --> G{Process Terminated?}
    G -->|Yes| H[Set Completion Time]
    G -->|No| I[Send SIGKILL to Process Group]
    I --> J[Force Wait for Process]
    J --> H
    H --> K[Update Status to 'completed']
    K --> L[Log to Execution History]
    L --> M[Remove from Running Tasks]
    M --> N[Print 'Killed task_id']
```

### Configuration Reload Flow

```mermaid
flowchart TD
    A[User Types 'reload'] --> B[Read YAML File]
    B --> C{File Exists?}
    C -->|No| D[Create Empty YAML] --> E
    C -->|Yes| E[Parse YAML Content]
    E --> F{Valid YAML?}
    F -->|No| G[Print Error Message]
    F -->|Yes| H[Convert to Task Objects]
    H --> I{Valid Task Structure?}
    I -->|No| G
    I -->|Yes| J[Replace Task List]
    J --> K[Print Success Message]
    G --> L[Keep Existing Tasks]
    K --> M[Continue Operation]
    L --> M
```

## Component Design

### GPUResourceManager Class

```python
class GPUResourceManager:
    """Main orchestrator class managing all system components"""

    # Core Data Structures
    tasks: List[Task]                    # All tasks from YAML
    running_tasks: Dict[str, Task]       # Currently executing tasks
    occupation_process: subprocess.Popen # GPU occupation process

    # Threading
    monitor_thread: threading.Thread     # Background task monitor
    shutdown_requested: bool             # Shutdown coordination flag

    # File Management
    yaml_file: str                       # Tasks configuration file
    history_file: str                    # Execution history file
    occupation_script: str               # GPU occupation script path

    # Core Methods
    def __init__(yaml_file, history_file)
    def reload_tasks() -> bool
    def _start_task(task) -> bool
    def _monitor_tasks()                 # Background thread main loop
    def kill_task(task_id) -> bool
    def get_status() -> str
    def run_command_loop()               # Main thread command interface
    def shutdown()
```

### Task Dataclass

```python
@dataclass
class Task:
    """Represents a single executable task with metadata"""

    # Required YAML Fields
    id: str                              # Unique identifier
    command: str                         # Executable command/script
    gpu_indices: List[int]               # GPU card assignments
    log_file: str                        # Output log file path
    run_together: bool                   # Concurrency flag
    status: str                          # Current state

    # Runtime Fields
    process: Optional[subprocess.Popen]  # Active process object
    started_at: Optional[str]            # ISO timestamp
    completed_at: Optional[str]          # ISO timestamp
```

### Process Management System

```python
class ProcessManager:
    """Handles subprocess lifecycle management"""

    def create_process(task: Task) -> subprocess.Popen:
        """Create isolated process with proper environment"""
        env = os.environ.copy()
        env['CUDA_VISIBLE_DEVICES'] = ','.join(map(str, task.gpu_indices))

        return subprocess.Popen(
            task.command,
            shell=True,
            env=env,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            preexec_fn=os.setsid  # New process group
        )

    def terminate_process(process: subprocess.Popen):
        """Graceful -> Force termination strategy"""
        # Step 1: Graceful termination
        os.killpg(os.getpgid(process.pid), signal.SIGTERM)

        # Step 2: Wait with timeout
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            # Step 3: Force termination
            os.killpg(os.getpgid(process.pid), signal.SIGKILL)
            process.wait()
```

## Data Flow

### YAML Configuration Flow

```
tasks.yaml → YAML Parser → Task Objects → Task List → Scheduler
    ↓
Status Updates ← YAML Writer ← Task Status Changes ← Process Monitor
```

### Execution History Flow

```
Task Start → Runtime Data → Task Completion → History Entry → execution_history.yaml
```

### Log File Flow

```
Task Process → stdout/stderr → Log File (per task)
System Events → stdout → Console Output
```

### Command Flow

```
stdin → Command Parser → Action Handler → System State Change → Response
```

## State Management

### Task State Machine

```mermaid
stateDiagram-v2
    [*] --> pending: Task defined in YAML
    pending --> running: Scheduler starts task
    running --> completed: Task finishes naturally
    running --> completed: Task killed by user
    completed --> [*]: Task archived to history

    note right of pending: Waiting in queue
    note right of running: Active subprocess
    note right of completed: Logged to history
```

### System State Machine

```mermaid
stateDiagram-v2
    [*] --> startup: Application launch
    startup --> idle: No tasks to run
    startup --> executing: Tasks available
    executing --> idle: All tasks complete
    idle --> executing: New tasks added
    executing --> executing: Task completion/new starts
    idle --> occupation: No pending tasks
    occupation --> executing: New tasks available
    executing --> shutdown: User quit command
    idle --> shutdown: User quit command
    occupation --> shutdown: User quit command
    shutdown --> [*]: Cleanup complete
```

### Resource State Tracking

```python
class SystemState:
    """Tracks overall system resource state"""

    # Task States
    pending_tasks: int
    running_tasks: int
    completed_tasks: int

    # Resource States
    gpu_occupation_active: bool
    available_gpus: Set[int]
    allocated_gpus: Dict[str, List[int]]  # task_id -> gpu_indices

    # Process States
    active_processes: Dict[str, int]      # task_id -> PID
    zombie_processes: List[int]           # PIDs to cleanup
```

## Concurrency Model

### Thread Responsibilities

#### Main Thread
- **Primary Role**: User interface and command processing
- **Responsibilities**:
  - Process stdin commands
  - Coordinate system shutdown
  - Handle signal interrupts
  - Initialize system components

#### Monitor Thread (Daemon)
- **Primary Role**: Task lifecycle management
- **Responsibilities**:
  - Continuously monitor running processes
  - Start new tasks based on scheduling rules
  - Update task statuses
  - Manage GPU occupation process
  - Clean up completed tasks

### Synchronization Strategy

```python
# Thread-safe data structures
import threading

class ThreadSafeTaskManager:
    def __init__(self):
        self._lock = threading.Lock()
        self._running_tasks = {}
        self._task_list = []

    def add_running_task(self, task_id: str, task: Task):
        with self._lock:
            self._running_tasks[task_id] = task

    def remove_running_task(self, task_id: str):
        with self._lock:
            return self._running_tasks.pop(task_id, None)

    def get_running_tasks(self) -> Dict[str, Task]:
        with self._lock:
            return self._running_tasks.copy()
```

### Race Condition Prevention

#### Task Starting Race Conditions
```python
def _start_task_atomic(self, task: Task) -> bool:
    """Atomically check and start task to prevent race conditions"""
    with self._task_lock:
        # Re-check conditions under lock
        if not self._can_start_task(task):
            return False

        # Immediately mark as starting to prevent duplicate starts
        task.status = "starting"

        # Start the actual process
        success = self._do_start_task(task)

        if success:
            task.status = "running"
            self.running_tasks[task.id] = task
        else:
            task.status = "pending"

        return success
```

#### Status Update Race Conditions
```python
def _update_task_status_atomic(self, task_id: str, new_status: str):
    """Atomically update task status across all data structures"""
    with self._status_lock:
        # Update in-memory task
        for task in self.tasks:
            if task.id == task_id:
                task.status = new_status
                break

        # Update YAML file
        self._write_yaml_atomic()

        # Update history if completed
        if new_status == "completed":
            self._log_execution_history(task)
```

## Error Handling Strategy

### Error Categories and Responses

#### 1. Configuration Errors
```python
def handle_yaml_error(self, error: yaml.YAMLError) -> bool:
    """Handle YAML parsing errors gracefully"""
    print(f"YAML parsing error: {error}")
    # Keep existing task configuration
    # Allow system to continue operating
    return False  # Indicate reload failed
```

#### 2. Process Errors
```python
def handle_process_error(self, task: Task, error: Exception):
    """Handle subprocess creation/management errors"""
    print(f"Error starting task {task.id}: {error}")
    # Mark task as failed but don't crash system
    task.status = "pending"  # Allow retry
    # Log error for debugging
    self._log_error(task.id, str(error))
```

#### 3. Resource Errors
```python
def handle_resource_error(self, error: OSError):
    """Handle system resource exhaustion"""
    print(f"Resource error: {error}")
    # Implement backoff strategy
    time.sleep(5)
    # Try to free resources
    self._cleanup_zombie_processes()
    # Reduce concurrent task limit temporarily
    self._enable_conservative_mode()
```

#### 4. Signal Handling
```python
def _signal_handler(self, signum: int, frame):
    """Handle system signals gracefully"""
    signal_names = {2: "SIGINT", 15: "SIGTERM"}
    signal_name = signal_names.get(signum, f"Signal {signum}")

    print(f"\nReceived {signal_name}, initiating graceful shutdown...")
    self.shutdown_requested = True

    # Allow current operations to complete
    # Monitor thread will see shutdown_requested and cleanup
```

### Error Recovery Patterns

#### Circuit Breaker Pattern
```python
class TaskStartCircuitBreaker:
    """Prevent cascade failures in task starting"""

    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.last_failure_time = 0
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN

    def can_start_task(self) -> bool:
        if self.state == "OPEN":
            if time.time() - self.last_failure_time > self.timeout:
                self.state = "HALF_OPEN"
                return True
            return False
        return True

    def record_success(self):
        self.failure_count = 0
        self.state = "CLOSED"

    def record_failure(self):
        self.failure_count += 1
        self.last_failure_time = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = "OPEN"
```

#### Retry with Exponential Backoff
```python
def retry_with_backoff(self, operation, max_retries=3):
    """Retry failed operations with exponential backoff"""
    for attempt in range(max_retries):
        try:
            return operation()
        except Exception as e:
            if attempt == max_retries - 1:
                raise e

            backoff_time = 2 ** attempt
            print(f"Operation failed, retrying in {backoff_time} seconds...")
            time.sleep(backoff_time)
```

### Monitoring and Health Checks

#### System Health Monitoring
```python
def _health_check(self) -> Dict[str, bool]:
    """Comprehensive system health check"""
    health = {}

    # Check file system health
    health['yaml_readable'] = os.access(self.yaml_file, os.R_OK)
    health['log_dir_writable'] = os.access("logs", os.W_OK)

    # Check process health
    health['monitor_thread_alive'] = self.monitor_thread.is_alive()
    health['no_zombie_processes'] = len(self._get_zombie_processes()) == 0

    # Check resource health
    health['memory_available'] = self._check_memory_usage() < 0.9
    health['disk_space_available'] = self._check_disk_usage() < 0.9

    return health
```

This comprehensive system design document provides complete technical details of the GPU Resource Manager architecture, including all process flows, component interactions, concurrency handling, and error management strategies. The diagrams and code examples illustrate exactly how the system operates at every level.