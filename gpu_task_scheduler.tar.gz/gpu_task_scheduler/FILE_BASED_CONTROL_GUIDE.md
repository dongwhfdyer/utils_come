# GPU Resource Manager - File-Based Control System

## Overview

This version of the GPU Resource Manager is specifically designed for deployment on training platforms where interactive terminal access (stdin/stdout) is not available. Instead of using interactive commands, the system uses **file-based signaling** for all control operations.

## Key Benefits for Platform Deployment

✅ **No Terminal Dependency**: Works without stdin/stdout access
✅ **File-Based Control**: All commands executed via signal files
✅ **Platform Integration**: Can be controlled through file uploads or scripts
✅ **Persistent Operation**: Continues running indefinitely as required
✅ **Comprehensive Logging**: All operations logged to files

## Quick Start

### 1. Start the System
```bash
python3 gpu_resource_manager.py
```

### 2. Control via Signal Files
```bash
# Request current status
echo "timestamp: $(date -Iseconds)" > control/status.request

# Reload task configuration
echo "timestamp: $(date -Iseconds)" > control/reload.signal

# Kill all running tasks
echo "timestamp: $(date -Iseconds)" > control/kill_all.signal

# Kill specific task
echo "task_id: training_job_1" > control/kill_task_training_job_1.signal

# Shutdown system
echo "timestamp: $(date -Iseconds)" > control/shutdown.signal
```

### 3. Monitor Status
```bash
# View current status
cat control/current_status.txt

# View system log
tail -f system.log
```

## File-Based Control Architecture

### Control Directory Structure
```
control/
├── USAGE_INSTRUCTIONS.txt      # Command reference
├── current_status.txt           # Live system status (updated automatically)
├── status.output               # Response to status.request (created on demand)
│
# Signal files (created by user, deleted after processing):
├── reload.signal               # Trigger configuration reload
├── status.request              # Request detailed status
├── kill_all.signal             # Kill all running tasks
├── kill_task_<task_id>.signal  # Kill specific task
└── shutdown.signal             # Graceful system shutdown
```

### Signal File Processing
1. **Signal Creation**: User/script creates signal file with appropriate content
2. **Detection**: System monitors control directory every 1 second
3. **Processing**: System processes the signal and performs the requested action
4. **Cleanup**: Signal file is automatically deleted after processing
5. **Logging**: All operations logged to `system.log` with timestamps

## Platform Deployment Scenarios

### Scenario 1: Jupyter Notebook Environment
```python
# In a Jupyter notebook cell, you can control the system:

# Check status
with open('control/status.request', 'w') as f:
    f.write(f'timestamp: {datetime.now().isoformat()}')

# Wait and read status
import time
time.sleep(2)
with open('control/status.output', 'r') as f:
    print(f.read())

# Add new task and reload
with open('tasks.yaml', 'a') as f:
    f.write('''
- id: new_jupyter_task
  command: /path/to/script.sh
  gpu_indices: [0, 1]
  log_file: /logs/jupyter_task.log
  run_together: true
  status: pending
''')

# Trigger reload
with open('control/reload.signal', 'w') as f:
    f.write(f'timestamp: {datetime.now().isoformat()}')
```

### Scenario 2: Web Interface Integration
```python
# Flask/Django web interface can control the system:

@app.route('/gpu_manager/status')
def get_status():
    # Request status
    with open('control/status.request', 'w') as f:
        f.write(f'timestamp: {datetime.now().isoformat()}')

    # Wait for response
    time.sleep(1)

    # Return status
    with open('control/status.output', 'r') as f:
        return f.read()

@app.route('/gpu_manager/kill/<task_id>')
def kill_task(task_id):
    with open(f'control/kill_task_{task_id}.signal', 'w') as f:
        f.write(f'task_id: {task_id}\\ntimestamp: {datetime.now().isoformat()}')
    return f'Kill signal sent for {task_id}'
```

### Scenario 3: Platform File Upload
On platforms that allow file uploads:

1. **Modify tasks.yaml**: Upload new task configuration
2. **Upload reload signal**: Upload `reload.signal` file to `control/` directory
3. **Monitor via status**: Download `current_status.txt` to check progress
4. **Control execution**: Upload appropriate signal files as needed

### Scenario 4: SSH Script Automation
```bash
#!/bin/bash
# Remote control script for platforms with limited SSH access

# Function to send command
send_command() {
    local cmd_type=$1
    local cmd_data=$2

    echo "$cmd_data" > "control/${cmd_type}"
    echo "Sent command: $cmd_type"

    # Wait for processing
    sleep 2

    # Show updated status
    echo "=== Current Status ==="
    cat control/current_status.txt
}

# Usage examples:
send_command "reload.signal" "timestamp: $(date -Iseconds)"
send_command "kill_task_old_job.signal" "task_id: old_job"
send_command "status.request" "timestamp: $(date -Iseconds)"
```

## Signal File Formats

### Basic Signal Files
Most commands use simple timestamp format:
```bash
# reload.signal, kill_all.signal, shutdown.signal
timestamp: 2025-09-28T10:30:00
```

### Task-Specific Kill Signal
```bash
# kill_task_<task_id>.signal
task_id: training_model_a
timestamp: 2025-09-28T10:30:00
```

### Status Request with Options
```bash
# status.request
timestamp: 2025-09-28T10:30:00
format: detailed    # optional: 'detailed' or 'brief'
```

## Monitoring and Status Files

### Real-time Status: `control/current_status.txt`
Updated automatically whenever system state changes:
```
# Status updated at 2025-09-28T19:15:07.125497
=== GPU Resource Manager Status ===
Tasks file: tasks.yaml
Total tasks: 7
Timestamp: 2025-09-28T19:15:07.124515

Running tasks (2):
  training_model_a: GPUs [0, 1, 2, 3], PID 12345
  inference_job: GPUs [4, 5], PID 12346

Pending tasks (1):
  preprocessing: GPUs [0, 1, 2, 3, 4, 5, 6, 7], concurrent=false

Completed tasks (4):
  previous_job_1: Completed at 2025-09-28T10:15:23.123456
  previous_job_2: Completed at 2025-09-28T10:20:45.789012
  ... and 2 more

GPU occupation: Stopped
```

### System Log: `system.log`
Complete operational log with timestamps:
```
[2025-09-28T19:12:36.951340] Successfully loaded 6 tasks from tasks.yaml
[2025-09-28T19:12:36.952085] Signal monitoring thread started
[2025-09-28T19:12:36.955168] GPU Resource Manager started in file-based mode
[2025-09-28T19:13:28.888788] Processing status request
[2025-09-28T19:14:22.588684] Processing reload signal
[2025-09-28T19:14:23.939778] Started task file_based_test_task (PID: 89414) on GPUs [0, 1]
[2025-09-28T19:14:36.258670] Task file_based_test_task completed (exit code: 0)
```

### On-Demand Status: `control/status.output`
Created in response to `status.request`:
```
# Status generated at 2025-09-28T19:13:28.892163
=== GPU Resource Manager Status ===
[detailed status information]
```

## Platform-Specific Integration

### Google Colab / Jupyter
```python
import os
import time
from datetime import datetime

class GPUManagerControl:
    def __init__(self, control_dir='control'):
        self.control_dir = control_dir

    def request_status(self):
        signal_file = f'{self.control_dir}/status.request'
        with open(signal_file, 'w') as f:
            f.write(f'timestamp: {datetime.now().isoformat()}')

        # Wait for processing
        time.sleep(2)

        # Read result
        status_file = f'{self.control_dir}/status.output'
        if os.path.exists(status_file):
            with open(status_file, 'r') as f:
                return f.read()
        return "Status not available"

    def reload_tasks(self):
        signal_file = f'{self.control_dir}/reload.signal'
        with open(signal_file, 'w') as f:
            f.write(f'timestamp: {datetime.now().isoformat()}')
        return "Reload signal sent"

    def kill_task(self, task_id):
        signal_file = f'{self.control_dir}/kill_task_{task_id}.signal'
        with open(signal_file, 'w') as f:
            f.write(f'task_id: {task_id}\\ntimestamp: {datetime.now().isoformat()}')
        return f"Kill signal sent for {task_id}"

# Usage in notebook:
manager = GPUManagerControl()
print(manager.request_status())
```

### AWS SageMaker / Cloud Platforms
```python
# For cloud platforms with file system access
import boto3
import json

def control_gpu_manager_from_s3():
    s3 = boto3.client('s3')

    # Download current config
    s3.download_file('my-bucket', 'gpu-manager/tasks.yaml', 'tasks.yaml')

    # Add new task
    with open('tasks.yaml', 'a') as f:
        f.write(new_task_config)

    # Upload updated config
    s3.upload_file('tasks.yaml', 'my-bucket', 'gpu-manager/tasks.yaml')

    # Send reload signal
    with open('control/reload.signal', 'w') as f:
        f.write(f'timestamp: {datetime.now().isoformat()}')

    return "Configuration updated and reload triggered"
```

## Error Handling in File-Based Mode

### Signal File Validation
- **Missing files**: Ignored silently
- **Invalid format**: Logged to system.log, file deleted
- **Permission errors**: Logged to system.log, operation skipped
- **Processing errors**: Logged with details, system continues

### Recovery Procedures
```bash
# If system becomes unresponsive:

# 1. Check system log
tail -50 system.log

# 2. Check current status
cat control/current_status.txt

# 3. Force status update
echo "timestamp: $(date -Iseconds)" > control/status.request
sleep 3
cat control/status.output

# 4. If needed, force shutdown
echo "timestamp: $(date -Iseconds)" > control/shutdown.signal
```

## Best Practices for Platform Deployment

### 1. Monitoring Strategy
```bash
# Set up monitoring script
#!/bin/bash
while true; do
    echo "=== $(date) ==="
    cat control/current_status.txt
    echo ""
    sleep 30
done > monitoring.log 2>&1 &
```

### 2. Task Configuration Management
- Keep `tasks.yaml` in version control
- Use absolute paths for all scripts and logs
- Test configurations locally before platform deployment
- Include task descriptions in comments

### 3. Resource Management
```yaml
# Example production configuration
tasks:
  - id: priority_training
    command: /opt/ml/train_priority_model.sh
    gpu_indices: [0, 1, 2, 3]
    log_file: /logs/priority_training.log
    run_together: false  # Exclusive access
    status: pending

  - id: background_inference
    command: /opt/ml/run_inference.sh
    gpu_indices: [4, 5, 6, 7]
    log_file: /logs/inference.log
    run_together: true   # Can run with others
    status: pending
```

### 4. Platform Integration Scripts
```bash
# Deploy script for platform
#!/bin/bash
set -e

echo "Deploying GPU Resource Manager..."

# Copy files to platform
cp gpu_resource_manager_file_based.py /workspace/
cp tasks.yaml /workspace/
cp -r scripts/ /workspace/

# Create log directory
mkdir -p /workspace/logs

# Start system
cd /workspace
nohup python3 gpu_resource_manager_file_based.py > startup.log 2>&1 &

# Wait for initialization
sleep 5

# Verify system is running
if [ -f "control/current_status.txt" ]; then
    echo "✅ GPU Resource Manager started successfully"
    cat control/current_status.txt
else
    echo "❌ Failed to start GPU Resource Manager"
    cat startup.log
    exit 1
fi
```

## Migration from Interactive to File-Based

### Key Differences
| Interactive Version | File-Based Version |
|---------------------|-------------------|
| `> status` | `echo "timestamp: $(date -Iseconds)" > control/status.request` |
| `> reload` | `echo "timestamp: $(date -Iseconds)" > control/reload.signal` |
| `> kill task_id` | `echo "task_id: task_id" > control/kill_task_task_id.signal` |
| `> kill_all` | `echo "timestamp: $(date -Iseconds)" > control/kill_all.signal` |
| `> quit` | `echo "timestamp: $(date -Iseconds)" > control/shutdown.signal` |

### Compatibility
- Same `tasks.yaml` format
- Same `execution_history.yaml` logging
- Same GPU occupation behavior
- Same task scheduling logic
- Same error handling and recovery

The file-based version provides identical functionality while being perfectly suited for restrictive platform environments where terminal access is not available.