#!/bin/bash
# Simple GPU occupation script - maintains minimal GPU utilization
# Uses nvidia-ml-py or a simple CUDA kernel to keep GPUs busy

python3 -c "
import time
import subprocess

print('Starting GPU occupation to maintain platform resources...')
print('This process will run until terminated by the resource manager.')

try:
    # Simple GPU utilization using nvidia-smi
    while True:
        for gpu_id in range(8):  # Assume 8 GPUs
            try:
                subprocess.run(['nvidia-smi', '-i', str(gpu_id), '--query-gpu=utilization.gpu', '--format=csv,noheader,nounits'],
                             capture_output=True, timeout=1)
            except:
                pass
        time.sleep(10)  # Check every 10 seconds
except KeyboardInterrupt:
    print('GPU occupation script terminated.')
"
